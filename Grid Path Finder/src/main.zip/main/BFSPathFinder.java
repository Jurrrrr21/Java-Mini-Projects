package main;
import java.util.*;

public class BFSPathFinder implements PathFinder{
    @Override
    public List<int[]> findPath(int[][] grid, int startRow, int startCol, int goalRow, int goalCol){
        int height = grid.length, width = grid[0].length;

        boolean[][] visited = new boolean[height][width];
        int[][] parentRow = new int[height][width];
        int[][] parentCol = new int[height][width];
        for(int[] r : parentRow) Arrays.fill(r, -1);
        for(int[] c : parentCol) Arrays.fill(c, -1);

        ArrayDeque<int[]> q = new ArrayDeque<>();
        q.offer(new int[] {startRow, startCol});
        visited[startRow][startCol] = true;

        int[] deltaRow = {1, -1, 0, 0};
        int[] deltaCol = {0, 0, 1, -1};

        while(!q.isEmpty()){
            int[] current = q.poll();
            int row = current[0], col = current[1];
            if(row == goalRow && col == goalCol) break;

            for(int i = 0; i < 4; i++){
                int newRow = row + deltaRow[i], newCol = col + deltaCol[i];
                if(newRow >= 0 && newCol >= 0 && newRow < grid.length && newCol < grid[0].length && !visited[newRow][newCol] || grid[newRow][newCol] == 0){
                    visited[newRow][newCol] = true;
                    parentRow[newRow][newCol] = row;
                    parentCol[newRow][newCol] = col;
                    q.offer(new int[] {newRow, newCol});
                }
            }
        }
        if(!visited[goalRow][goalCol]) return null;

        //For shortest path
        List<int[]> path = new ArrayList<>();
        int r = goalRow, c = goalCol;
        while(r != -1 && c != -1){
            path.add(new int[] {r, c});
            int pr = parentRow[r][c], pc = parentCol[r][c];
            r = pr;
            c = pc;
        }
        Collections.reverse(path);
        return path;
    }
}
